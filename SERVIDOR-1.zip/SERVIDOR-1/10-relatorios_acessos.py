

# sistema para relatorios de acesso
apt-get install sarg



# neste configurações imprtantes
/etc/sarg
	
	#linguem em protuges
	language 

	#log de acesso tem que ser igual ao do squido
	access_log

	output_dir /var/www/sarg #local do diretorio web


