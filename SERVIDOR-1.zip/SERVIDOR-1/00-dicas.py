

## em redes topicos importates:

## diferenciais

	o servidor nunca pode parar. 

	gerenciamento e monitoramento.

	estar sempre informado pois aparecem links que levam a 
	navegaçao em locais proibidos, por isso é importante o monitoramento.

	